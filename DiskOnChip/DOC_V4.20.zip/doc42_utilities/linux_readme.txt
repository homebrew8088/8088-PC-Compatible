The Diskonchip Linux image is named TriLinux.img.

To install image onto Diskonchip, use the following command:

		putmimg Trilinux.img

Note: You must issue the command in DOS, not DOS prompt under WIN95/98.